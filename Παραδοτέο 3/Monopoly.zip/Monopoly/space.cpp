#include <iostream>
#include "space.h"

// TODO: Implement here the methods of Space, Property, RailRoad, Utility, and Tax
Space::Space(int id, string name, SpaceType type, string actionText){
    this-> id= id;
    this-> name= name;
    this-> type= type;
    this-> actionText= actionText;
    owner=0;
}

int Space::getId(){
    return id;
}

string Space::getName(){
    return name;
}

string Space::getActionText(){
    return actionText;
}

void Space::setOwner(Player* owner){
    this->owner= owner;
}

bool Space::typeIs(SpaceType type){
    return this->type==type;
}

bool Space::ownerIs(Player* player){
    return owner==player;
}

Property::Property(int id, string name, SpaceType type, string actionText, int buyCost, int upgradeCost, PropertyCategory category): Space::Space(id, name, type, actionText){
    this-> buyCost=buyCost;
    this-> upgradeCost=upgradeCost;
    this-> category=category;
    numberOfHouses=0;
}

void Property::setRent(int numberOfHouses, int inputRent){
    rent[numberOfHouses] = inputRent;
}

int Property::getBuyingCost(){
    return buyCost;
}

int Property::getUpgradeCost(){
    return upgradeCost;
}

int Property::getNumberOfHouses(){
    return numberOfHouses;
}

PropertyCategory Property::getCategory(){
    return category;
}

int Property::getRent(){
    return rent[numberOfHouses];
}

void Property::addHouse(){
    numberOfHouses += 1;
}

RailRoad::RailRoad(int id, string name, SpaceType type, string actionText, int buyCost): Space::Space(id, name, type, actionText){
    this->buyCost=buyCost;
}

void RailRoad::setRent(int numberOfRailRoads, int inputRent){
    rent[numberOfRailRoads - 1] = inputRent;
}

int RailRoad::getBuyingCost(){
    return buyCost;
}

int RailRoad::getRent(){
    return rent[owner->getNumberOfRailRoadsOwned() - 1];
}

Utility::Utility(int id, string name, SpaceType type, string actionText, int buyCost, Dice* dice): Space::Space(id, name, type, actionText){
    this->buyCost=buyCost;
}

void Utility::setRentMultiplier(int numberOfUtilities, int inputRentMultiplier){
    rentMultiplier[numberOfUtilities - 1] = inputRentMultiplier;
}

int Utility::getBuyingCost(){
    return buyCost;
}

int Utility::getRent(){
    return rentMultiplier[owner->getNumberOfUtilitiesOwned() - 1]*(dice->getFirstDice() + dice->getSecondDice());
}

Tax::Tax(int id, string name, SpaceType type, string actionText, int tax): Space::Space(id, name, type, actionText){
    this-> tax=tax;
}

int Tax::getTax(){
    return tax;
}
