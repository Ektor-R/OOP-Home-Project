#include<iostream>

using namespace std;

template <class X> void shuffle(X** myArray, int myArraySize){
    // TODO: Implement here the shuffle algorithm
    int i, j;
    X* temp;

    for (i=myArraySize-1; i>0; --i){
        j= rand() % (i +1);
        temp = myArray[i];
        myArray[i] = myArray[j];
        myArray[j] = temp;
    }
}
